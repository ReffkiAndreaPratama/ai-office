$ProgressPreference = 'SilentlyContinue'
$ErrorActionPreference = 'Continue'
$headers = @{ "User-Agent" = "Mozilla/5.0" }
$aoBase = "https://raw.githubusercontent.com/dkyazzentwatwa/agent-office/main"

$empFiles = @(
    "account_executive.md","account_manager.md","brand_manager.md","briefing_officer.md",
    "business_development_manager.md","ceo_strategy.md","cfo.md","community_manager.md",
    "compliance_officer.md","content_writer.md","cto.md","customer_success_manager.md",
    "data_analyst.md","data_scientist.md","devops_engineer.md","executive_assistant.md",
    "facilities_manager.md","financial_analyst.md","flow_helper_support_admin.md","hr_coordinator.md",
    "internal_communications.md","investor_relations.md","it_support.md","legal_counsel.md",
    "marketing_coordinator.md","operations_manager.md","payroll_specialist.md","procurement_specialist.md",
    "product_manager.md","project_manager.md","quality_assurance_manager.md","recruiter.md",
    "release_manager.md","sales_manager.md","sdr.md","security_analyst.md","seo_specialist.md",
    "social_media_crawler.md","social_media_manager.md","solutions_architect.md","support_specialist.md",
    "technical_writer.md","training_specialist.md","ux_ui_designer.md"
)

$opsFiles = @(
    @{url="$aoBase/OFFICE_OPS/DASHBOARD_README.md"; dest="D:\Games\ai-office\OFFICE_OPS\DASHBOARD_README.md"},
    @{url="$aoBase/OFFICE_OPS/OPERATIONS_GUIDE.md"; dest="D:\Games\ai-office\OFFICE_OPS\OPERATIONS_GUIDE.md"},
    @{url="$aoBase/OFFICE_OPS/README.md"; dest="D:\Games\ai-office\OFFICE_OPS\README.md"},
    @{url="$aoBase/OFFICE_OPS/dashboard.html"; dest="D:\Games\ai-office\OFFICE_OPS\dashboard.html"},
    @{url="$aoBase/OFFICE_OPS/coordination/COORDINATION_MATRIX.md"; dest="D:\Games\ai-office\OFFICE_OPS\coordination\COORDINATION_MATRIX.md"},
    @{url="$aoBase/OFFICE_OPS/coordination/README.md"; dest="D:\Games\ai-office\OFFICE_OPS\coordination\README.md"},
    @{url="$aoBase/OFFICE_OPS/employees/README.md"; dest="D:\Games\ai-office\OFFICE_OPS\employees\README.md"},
    @{url="$aoBase/OFFICE_OPS/employees/ROSTER.md"; dest="D:\Games\ai-office\OFFICE_OPS\employees\ROSTER.md"},
    @{url="$aoBase/OFFICE_OPS/incidents/README.md"; dest="D:\Games\ai-office\OFFICE_OPS\incidents\README.md"},
    @{url="$aoBase/OFFICE_OPS/processes/DAILY_ROUTINE_SOP.md"; dest="D:\Games\ai-office\OFFICE_OPS\processes\DAILY_ROUTINE_SOP.md"},
    @{url="$aoBase/OFFICE_OPS/processes/README.md"; dest="D:\Games\ai-office\OFFICE_OPS\processes\README.md"},
    @{url="$aoBase/OFFICE_OPS/projects/README.md"; dest="D:\Games\ai-office\OFFICE_OPS\projects\README.md"},
    @{url="$aoBase/OFFICE_OPS/reporting/README.md"; dest="D:\Games\ai-office\OFFICE_OPS\reporting\README.md"},
    @{url="$aoBase/OFFICE_OPS/training/FIRST_USER_GUIDE.md"; dest="D:\Games\ai-office\OFFICE_OPS\training\FIRST_USER_GUIDE.md"},
    @{url="$aoBase/OFFICE_OPS/training/README.md"; dest="D:\Games\ai-office\OFFICE_OPS\training\README.md"}
)

$ok = 0
foreach ($f in $empFiles) {
    try {
        $r = Invoke-WebRequest -Uri "$aoBase/employee/$f" -Headers $headers -UseBasicParsing
        [System.IO.File]::WriteAllText("D:\Games\ai-office\employee\$f", $r.Content, [System.Text.Encoding]::UTF8)
        $ok++
        "EMP OK: $f" | Out-File "D:\Games\ai-office\download-log.txt" -Append
    } catch {
        "EMP FAIL: $f - $_" | Out-File "D:\Games\ai-office\download-log.txt" -Append
    }
}

foreach ($f in $opsFiles) {
    try {
        $r = Invoke-WebRequest -Uri $f.url -Headers $headers -UseBasicParsing
        [System.IO.File]::WriteAllText($f.dest, $r.Content, [System.Text.Encoding]::UTF8)
        $ok++
        "OPS OK: $($f.dest)" | Out-File "D:\Games\ai-office\download-log.txt" -Append
    } catch {
        "OPS FAIL: $($f.url) - $_" | Out-File "D:\Games\ai-office\download-log.txt" -Append
    }
}

# docs
foreach ($f in @("claude-cowork-instructions.md","codex-instructions.md")) {
    try {
        $r = Invoke-WebRequest -Uri "$aoBase/docs/$f" -Headers $headers -UseBasicParsing
        [System.IO.File]::WriteAllText("D:\Games\ai-office\docs\$f", $r.Content, [System.Text.Encoding]::UTF8)
        $ok++
    } catch {}
}

"TOTAL OK: $ok" | Out-File "D:\Games\ai-office\download-log.txt" -Append
Write-Output "Done: $ok files"
