﻿# My First Game (Godot 4.7)

**Engine**: Godot 4.7.2 (Steam)
**Path**: D:\Games\my-first-game

## Mechanics
- [ ] Player movement
- [ ] Jump
- [ ] Enemy AI
- [ ] Save system
