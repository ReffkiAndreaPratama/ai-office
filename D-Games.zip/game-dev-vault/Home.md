﻿# Game Dev Vault

## Projects
- [[Godot/My First Game]]
- [[Roblox/My Roblox Game]]

## Quick Links
- [[Ideas/Game Ideas]]

## Active Tasks
``dataview
TASK FROM ""
WHERE !completed
LIMIT 20
``

## Recent Sessions
``dataview
TABLE date, project FROM "Sessions"
SORT date DESC
LIMIT 10
``
