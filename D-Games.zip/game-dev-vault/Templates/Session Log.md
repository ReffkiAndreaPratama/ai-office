﻿---
date: {{date}}
project: 
tags: [session]
---

# Session - {{date}}

## Goal
- 

## Done
- 

## Issues
- 

## Next
- 
