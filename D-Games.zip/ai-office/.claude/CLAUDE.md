# Claude Instructions — AI Game Studio + Virtual Office

## What This Workspace Is

This is a combined **game development studio** and **virtual office** powered by AI agents. You are operating in a professional studio environment with two active game projects and a full office operations structure.

---

## Active Game Projects

### Godot Project
- **Path:** `D:\Games\my-first-game`
- **Engine:** Godot 4.7.2 (Steam release)
- **MCP Server:** `godot-mcp`
- **Language options:** GDScript, C#, GDExtension (C++)
- **Key agents:** `godot-specialist`, `godot-gdscript-specialist`, `godot-csharp-specialist`, `godot-shader-specialist`, `godot-gdextension-specialist`

### Roblox Project
- **Path:** `D:\Games\my-roblox-game`
- **Toolchain:** Rojo 7.7.1 (file-sync to Roblox Studio)
- **MCP Server:** `roblox-studio`
- **Language:** Luau
- **Key agents:** `gameplay-programmer`, `ui-programmer`, `network-programmer`

---

## Invoking Agents

Agents are defined in `.claude/agents/` (game studio) and `employee/` (office staff).

To invoke an agent, either:
1. Address them by role: *"As creative director, review this design doc"*
2. Use Claude sub-agent syntax: `Use the creative-director agent`
3. Reference their file: `.claude/agents/creative-director.md`

### Studio Chain of Command
For large decisions, escalate: `gameplay-programmer → lead-programmer → technical-director → creative-director`

For creative decisions: `game-designer → creative-director`

For release decisions: `qa-lead → producer → release-manager`

### Office Chain of Command
For business decisions: `project-manager → CEO`

For technical infrastructure: `devops-engineer → CTO`

---

## MCP Servers Available

```json
{
  "godot-mcp": {
    "description": "Godot 4 editor integration — open scenes, run scripts, query node tree",
    "project": "D:\\Games\\my-first-game"
  },
  "roblox-studio": {
    "description": "Roblox Studio integration via Rojo",
    "project": "D:\\Games\\my-roblox-game"
  }
}
```

---

## Coding Standards

- **Godot GDScript:** snake_case, typed variables, `@export` for editor properties, signals for loose coupling
- **Godot C#:** PascalCase, `[Export]`, partial classes for Godot nodes
- **Luau (Roblox):** strict mode (`--!strict`), `type` declarations, ModuleScripts for shared logic
- All game code lives inside the respective project directories — never mix them
- Use Rojo `default.project.json` for Roblox file structure

---

## Agent Memory

Agent memory files live in `.claude/agent-memory/`. The lead programmer's memory is at:
`.claude/agent-memory/lead-programmer/MEMORY.md`

Add new agent memory folders as: `.claude/agent-memory/{agent-name}/MEMORY.md`

---

## Office Operations

Office docs are in `OFFICE_OPS/`:
- `OFFICE_OPS/OPERATIONS_GUIDE.md` — how the office runs
- `OFFICE_OPS/processes/DAILY_ROUTINE_SOP.md` — daily standup and triage SOP
- `OFFICE_OPS/coordination/COORDINATION_MATRIX.md` — who works with whom
- `OFFICE_OPS/employees/ROSTER.md` — full staff roster

---

## Templates

Game design and documentation templates are in `.claude/docs/templates/`. Use them for:
- Game Design Documents: `game-design-document.md`
- Sprint planning: `sprint-plan.md`
- Architecture decisions: `architecture-decision-record.md`
- Release notes: `release-notes.md`
- Post-mortems: `post-mortem.md`

---

## Important Paths

| Purpose | Path |
|---|---|
| This workspace | `D:\Games\ai-office` |
| Godot project | `D:\Games\my-first-game` |
| Roblox project | `D:\Games\my-roblox-game` |
| Obsidian vault | `D:\Games\game-dev-vault` |
| Studio agents | `D:\Games\ai-office\.claude\agents\` |
| Office employees | `D:\Games\ai-office\employee\` |
| Gemini skills | `C:\Users\tama\.gemini\config\skills\` |
| 9router | `C:\Users\tama\AppData\Roaming\npm\node_modules\9router\cli.js` |
