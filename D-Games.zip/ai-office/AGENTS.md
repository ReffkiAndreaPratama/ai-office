﻿# AI Office & Game Studio — Master Roster

## Setup
- **Godot**: D:\Games\my-first-game (Godot 4.7.2 Steam)
- **Roblox**: D:\Games\my-roblox-game (Rojo 7.7.1)
- **MCP**: godot-mcp, roblox-studio (aktif di Cursor/OpenCode/Antigravity)
- **9router**: http://localhost:20128

---

## 🎮 GAME STUDIO — 49 Agents

### Directors (level tertinggi)
| Agent | File | Tugasnya |
|---|---|---|
| creative-director | .claude/agents/creative-director.md | Penjaga visi game, keputusan kreatif final |
| technical-director | .claude/agents/technical-director.md | Arsitektur teknis, keputusan engine |
| narrative-director | .claude/agents/narrative-director.md | Cerita, dialog, lore |
| audio-director | .claude/agents/audio-director.md | Musik, SFX, audio direction |
| art-director | .claude/agents/art-director.md | Visual identity, art bible |

### Programming Leads & Specialists
| Agent | File | Tugasnya |
|---|---|---|
| lead-programmer | .claude/agents/lead-programmer.md | Arsitektur kode, code review |
| gameplay-programmer | .claude/agents/gameplay-programmer.md | Mekanik gameplay |
| engine-programmer | .claude/agents/engine-programmer.md | Engine internals, optimasi |
| network-programmer | .claude/agents/network-programmer.md | Multiplayer, networking |
| ai-programmer | .claude/agents/ai-programmer.md | AI enemy, pathfinding |
| tools-programmer | .claude/agents/tools-programmer.md | Dev tools, editor scripts |
| ui-programmer | .claude/agents/ui-programmer.md | UI/UX code |
| performance-analyst | .claude/agents/performance-analyst.md | Profiling, optimasi performa |
| security-engineer | .claude/agents/security-engineer.md | Anti-cheat, exploits |

### Godot Specialists
| Agent | File | Tugasnya |
|---|---|---|
| godot-specialist | .claude/agents/godot-specialist.md | Godot generalist |
| godot-gdscript-specialist | .claude/agents/godot-gdscript-specialist.md | GDScript expert |
| godot-csharp-specialist | .claude/agents/godot-csharp-specialist.md | C# di Godot |
| godot-shader-specialist | .claude/agents/godot-shader-specialist.md | GLSL shaders |
| godot-gdextension-specialist | .claude/agents/godot-gdextension-specialist.md | GDExtension/C++ |

### Design
| Agent | File | Tugasnya |
|---|---|---|
| game-designer | .claude/agents/game-designer.md | Mekanik, sistem, balancing |
| systems-designer | .claude/agents/systems-designer.md | Sistem game kompleks |
| level-designer | .claude/agents/level-designer.md | Level, map, layout |
| ux-designer | .claude/agents/ux-designer.md | User experience |
| economy-designer | .claude/agents/economy-designer.md | Ekonomi game, monetisasi |
| live-ops-designer | .claude/agents/live-ops-designer.md | Live ops, events |
| world-builder | .claude/agents/world-builder.md | World building, lore |

### Art & Audio
| Agent | File | Tugasnya |
|---|---|---|
| technical-artist | .claude/agents/technical-artist.md | Pipeline aset, shaders, optimasi |
| sound-designer | .claude/agents/sound-designer.md | SFX design |
| writer | .claude/agents/writer.md | Dialog, copy, narasi |

### Production & QA
| Agent | File | Tugasnya |
|---|---|---|
| producer | .claude/agents/producer.md | Sprint, timeline, scope |
| qa-lead | .claude/agents/qa-lead.md | Testing strategy, bug triage |
| qa-tester | .claude/agents/qa-tester.md | Test cases, bug reports |
| devops-engineer | .claude/agents/devops-engineer.md | CI/CD, build pipeline |
| release-manager | .claude/agents/release-manager.md | Release planning, store submission |
| analytics-engineer | .claude/agents/analytics-engineer.md | Telemetry, data |
| prototyper | .claude/agents/prototyper.md | Rapid prototyping |

### Misc Specialists
| Agent | File | Tugasnya |
|---|---|---|
| accessibility-specialist | .claude/agents/accessibility-specialist.md | Aksesibilitas game |
| community-manager | .claude/agents/community-manager.md | Komunitas, feedback |
| localization-lead | .claude/agents/localization-lead.md | Terjemahan, i18n |

---

## 🏢 VIRTUAL OFFICE — 44 Employees

### C-Suite
| Employee | File | Tugasnya |
|---|---|---|
| CEO | employee/ceo_strategy.md | Strategi bisnis, keputusan besar |
| CTO | employee/cto.md | Tech stack, infrastruktur |
| CFO | employee/cfo.md | Keuangan, budget |

### Product & Project
| Employee | File | Tugasnya |
|---|---|---|
| Product Manager | employee/product_manager.md | Roadmap produk |
| Project Manager | employee/project_manager.md | Jadwal, koordinasi tim |
| Solutions Architect | employee/solutions_architect.md | Desain solusi teknis |

### Content & Marketing
| Employee | File | Tugasnya |
|---|---|---|
| Content Writer | employee/content_writer.md | Blog, copy, dokumentasi |
| SEO Specialist | employee/seo_specialist.md | SEO, traffic |
| Social Media Manager | employee/social_media_manager.md | Konten sosmed |
| Marketing Coordinator | employee/marketing_coordinator.md | Kampanye marketing |

### Technical & Dev
| Employee | File | Tugasnya |
|---|---|---|
| DevOps Engineer | employee/devops_engineer.md | Infrastructure, deploy |
| IT Support | employee/it_support.md | Troubleshooting teknis |
| Technical Writer | employee/technical_writer.md | Dokumentasi teknis |
| Data Analyst | employee/data_analyst.md | Analisis data |
| Data Scientist | employee/data_scientist.md | ML, model data |
| QA Manager | employee/quality_assurance_manager.md | Testing, quality |
| Security Analyst | employee/security_analyst.md | Keamanan sistem |

### Operations
| Employee | File | Tugasnya |
|---|---|---|
| Operations Manager | employee/operations_manager.md | Operasi harian, routing tugas |
| Executive Assistant | employee/executive_assistant.md | Jadwal, komunikasi |
| HR Coordinator | employee/hr_coordinator.md | SDM, rekrut |
| Legal Counsel | employee/legal_counsel.md | Kontrak, hukum |
| Financial Analyst | employee/financial_analyst.md | Analisis keuangan |

---

## 📋 OFFICE SKILLS (via Antigravity/OpenCode)

| Skill | Kapan dipakai |
|---|---|
| standup | Daily standup summary |
| daily-triage | Prioritas tugas hari ini |
| calendar-triage | Jadwal & deadline |
| email-triage | Prioritas email/pesan |
| weekly-brief | Ringkasan mingguan |
| office-health-check | Cek status semua agent |
| office-manager-router | Route tugas ke agent yang tepat |
| onboard-agent | Tambah agent baru |

---

## 🚀 Cara Pakai

### Panggil agent game studio:
> "Sebagai godot-specialist, buat player controller untuk platformer 2D"
> "Sebagai qa-lead, buat test plan untuk sistem combat"
> "Sebagai creative-director, bantu definisikan pillar game saya"

### Panggil office employee:
> "Sebagai project-manager, buat sprint plan untuk 2 minggu ke depan"
> "Sebagai technical-writer, buat dokumentasi untuk sistem save"

### Di Antigravity:
Skill `studio-*` dan `office-*` aktif otomatis saat relevan.